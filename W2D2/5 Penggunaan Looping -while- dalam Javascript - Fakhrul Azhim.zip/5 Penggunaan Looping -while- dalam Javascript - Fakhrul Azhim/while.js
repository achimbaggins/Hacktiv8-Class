// I Love Coding
function hasilWhile() {
var hasil = 1;

while (hasil <= 20) {
    if(hasil % 2 === 0) {
        console.log(hasil + ' I Love Coding');
    }
    hasil++;
}
    }
hasilWhile();


// I will become fullstack developer
function tampil() {
var tampil = 20;

while (tampil >= 1) {
    if(tampil % 2 === 0) {
        console.log(tampil + ' I will become fullstack developer');
    }
    tampil--;
}
    }
tampil();