alert('Kita akan menghitung Luas Segitiga');
var a = prompt('Masukkan panjang Alas Segitiga!');
var b = prompt('Masukkan tinggi Segitiga!');
var h = a*b/2;
alert('Luas Segitiga : '+h);