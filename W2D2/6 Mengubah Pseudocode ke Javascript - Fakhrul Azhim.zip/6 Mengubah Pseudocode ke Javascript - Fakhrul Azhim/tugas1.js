var nama = prompt('Nama :');
var a = prompt('Angka Pembilang');
var b = prompt('Angka Penyebut');
var hasil = a/b;
alert('Halo '+nama+', ' +a+ ' dibagi ' +b+ ' adalah sama dengan '+hasil);