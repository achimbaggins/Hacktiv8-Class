function shoutOut() {
    console.log("Halo Function!");
}
shoutOut();